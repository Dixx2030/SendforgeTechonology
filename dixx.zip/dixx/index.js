const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Configuração para servir arquivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Rota para o primeiro site
app.get('/site1', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'termos-politica-privacidade.html'));
});

// Rota para o segundo site
app.get('/site2', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Redireciona a rota / para /site1
app.get('/', (req, res) => {
  res.redirect('/site1');
});

// Inicia o servidor
app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
