// Simple animation on scroll (for demonstration)
document.addEventListener('DOMContentLoaded', () => {
    const animatedEls = document.querySelectorAll('.animate-zoomIn, .animate-fadeInLeft, .animate-fadeInRight');
    const revealOnScroll = () => {
        const trigger = window.innerHeight * 0.92;
        animatedEls.forEach(el => {
            const rect = el.getBoundingClientRect();
            if(rect.top < trigger) el.classList.add('visible');
        });
    };
    window.addEventListener('scroll', revealOnScroll);
    revealOnScroll();

    // Fake contact form submission (no backend)
    const form = document.querySelector('.contact-form');
    if(form) {
        form.addEventListener('submit', e => {
            e.preventDefault();
            alert('Mensagem enviada com sucesso! Retornaremos em breve.');
            form.reset();
        });
    }
});